module AP_project {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    opens AP to javafx.graphics, javafx.fxml;
    exports AP;
}