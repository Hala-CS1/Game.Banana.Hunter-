package AP;

import java.io.Serializable;
import java.util.*;

public class Controller implements Serializable {

    public Player player = new Player(50, 50);
    public List<Coin> coins = new ArrayList<>();
    public List<Trap> traps = new ArrayList<>();

    private int score = 0;
    private int level = 1;
    private int time = 30;

    public boolean gameOver = false;

    public Controller() {
        level1();
    }

    // ================= LEVEL 1 =================
    public void level1() {

        level = 1;
        coins.clear();
        traps.clear();

        player.x = 50;
        player.y = 50;

        time = 30;
        score = 0;

        Random rand = new Random();

        for (int i = 0; i < 5; i++) {
            coins.add(new Coin(rand.nextInt(700) + 50,
                               rand.nextInt(500) + 50));
        }

        for (int i = 0; i < 8; i++) {
            traps.add(new Trap(rand.nextInt(700) + 50,
                               rand.nextInt(500) + 50));
        }
    }

    // ================= LEVEL 2 =================
    public void level2() {

        level = 2;
        coins.clear();
        traps.clear();

        player.x = 50;
        player.y = 50;

        time = 30;

        Random rand = new Random();

        for (int i = 0; i < 5; i++) {
            coins.add(new Coin(rand.nextInt(700) + 50,
                               rand.nextInt(500) + 50));
        }

        for (int i = 0; i < 8; i++) {

            int x, y;

            do {
                x = rand.nextInt(700) + 50;
                y = rand.nextInt(500) + 50;
            } while (Math.abs(x - 50) < 100 && Math.abs(y - 50) < 100);

            traps.add(new Trap(x, y));
        }
    }

    // ================= MOVE =================
    public void move(int dx, int dy) {

        if (gameOver) return;

        player.move(dx, dy);

        if (player.x < 0) player.x = 0;
        if (player.y < 0) player.y = 0;
        if (player.x > 760) player.x = 760;
        if (player.y > 560) player.y = 560;

        checkCoins();
        checkTraps();
        checkWin();
    }

    private void checkCoins() {
        for (Coin c : coins) {
            if (!c.isCollected()
                    && Math.abs(c.getX() - player.getX()) < 25
                    && Math.abs(c.getY() - player.getY()) < 25) {

            	c.collect();
                score++;
            }
        }
    }

    private void checkTraps() {
        for (Trap t : traps) {
            if (Math.abs(t.getX() - player.getX()) < 25
                    && Math.abs(t.getY() - player.getY()) < 25) {
                gameOver = true;
            }
        }
    }

    private void checkWin() {

        boolean all = coins.stream().allMatch(c -> c.collected);

        if (all && level == 1) {
            level2();
        } else if (all && level == 2) {
            gameOver = true;
        }
    }

    public void decrementTime() {
        if (!gameOver) {
            time--;
            if (time <= 0) gameOver = true;
        }
    }

    public int getScore() { return score; }
    public int getLevel() { return level; }
    public int getTime() { return time; }
}