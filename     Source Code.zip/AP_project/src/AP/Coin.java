package AP;

import java.io.Serializable;

public class Coin implements Serializable {
	public int x, y;
	public boolean collected;

	public Coin(int x, int y) {
		this.x = x;
		this.y = y;
		this.collected = false;

	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public boolean isCollected() {
		return collected;
	}

	public void collect() {
		this.collected = true;
	}

}
