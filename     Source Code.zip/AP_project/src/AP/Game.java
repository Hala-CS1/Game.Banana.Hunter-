package AP;

import javafx.scene.image.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import java.util.*;

public class Game extends Pane {

    public static final Image CoinVIEW = new Image("file:/C:/Users/للاعمال/Downloads/Coin.png");
    public static final Image TrapVIEW = new Image("file:/C:/Users/للاعمال/Downloads/Trap.png");
    public static final Image PlayerVIEW = new Image("file:/C:/Users/للاعمال/Downloads/Player.png");
    public static final Image bgView = new Image("file:/C:/Users/للاعمال/Downloads/bg.png");

    private ImageView playerView;
    private List<ImageView> coinViews = new ArrayList<>();
    private List<ImageView> trapViews = new ArrayList<>();

    private Pane gameLayer;
    private Pane darkLayer;

    public Game(Player player, List<Coin> coins, List<Trap> traps) {

        ImageView bg = new ImageView(bgView);
        bg.setFitWidth(800);
        bg.setFitHeight(600);

        gameLayer = new Pane();
        darkLayer = new Pane();

        getChildren().addAll(bg, gameLayer, darkLayer);

        playerView = new ImageView(PlayerVIEW);
        playerView.setFitWidth(80);
        playerView.setFitHeight(80);

        resetObjects(coins, traps);
    }

    public void updatePlayer(Player player) {
        playerView.setX(player.getX());
        playerView.setY(player.getY());
    }

    public void updateCoins(List<Coin> coins) {
        for (int i = 0; i < coins.size(); i++) {
            if (coins.get(i).isCollected()) {
                coinViews.get(i).setVisible(false);
            }
        }
    }

    // ================= LIGHT SYSTEM =================
    public void updateLight(Player player, int level) {

        darkLayer.getChildren().clear();

        if (level != 2) return;

        Rectangle dark = new Rectangle(800, 600);
        dark.setFill(Color.rgb(0, 0, 0, 0.85));

        Circle light = new Circle(
                player.getX() + 35,
                player.getY() + 35,
                120
        );

        Shape hole = Shape.subtract(dark, light);

        darkLayer.getChildren().add(hole);
    }

    // ================= RESET =================
    public void resetObjects(List<Coin> coins, List<Trap> traps) {

        gameLayer.getChildren().clear();
        coinViews.clear();
        trapViews.clear();

        for (Coin c : coins) {
            ImageView v = new ImageView(CoinVIEW);
            v.setFitWidth(60);
            v.setFitHeight(60);
            v.setX(c.getX());
            v.setY(c.getY());
            coinViews.add(v);
            gameLayer.getChildren().add(v);
        }

        for (Trap t : traps) {
            ImageView v = new ImageView(TrapVIEW);
            v.setFitWidth(55);
            v.setFitHeight(55);
            v.setX(t.getX());
            v.setY(t.getY());
            trapViews.add(v);
            gameLayer.getChildren().add(v);
        }

        gameLayer.getChildren().add(playerView);
    }
}