package AP;
import java.io.*;
public class FileManegment {
    public static void saveGameData(Object data, String fileName) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(data);
            System.out.println("Data has been saved in: " + fileName);
        } catch (IOException e) {
            System.err.println("Error saving your data " + e.getMessage());
        }
    }
    public static Object loadGameData(String fileName) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading data:" + e.getMessage());
            return null;
        }
    }
}