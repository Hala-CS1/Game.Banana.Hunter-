package AP;

	import javafx.application.Application;
	import javafx.scene.Scene;
	import javafx.scene.input.KeyCode;
	import javafx.stage.Stage;

	public class Main extends Application {

	    @Override
	    public void start(Stage stage) {

	        Controller controller = new Controller();

	        Game gameView = new Game(
	                controller.player,
	                controller.coins,
	                controller.traps
	        );

	        Scene scene = new Scene(gameView, 800, 600);

	        // حركة اللاعب بالكيبورد
	        scene.setOnKeyPressed(e -> {

	            if (controller.gameOver) return;

	            if (e.getCode() == KeyCode.UP) {
	                controller.move(0, -10);
	            }
	            if (e.getCode() == KeyCode.DOWN) {
	                controller.move(0, 10);
	            }
	            if (e.getCode() == KeyCode.LEFT) {
	                controller.move(-10, 0);
	            }
	            if (e.getCode() == KeyCode.RIGHT) {
	                controller.move(10, 0);
	            }

	            // تحديث الشاشة
	            gameView.updatePlayer(controller.player);
	        });

	        stage.setTitle("Treasure Hunter Game");
	        stage.setScene(scene);
	        stage.show();
	    }

	    public static void main(String[] args) {
	        launch(args);
	    }
	}