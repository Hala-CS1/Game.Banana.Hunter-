package AP;

import java.io.Serializable;

public class Player implements Serializable {
	public int x, y;

	public Player(int x, int y) {

		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public void move(int dx, int dy) {
		x += dx;
		y += dy;
	}

}
