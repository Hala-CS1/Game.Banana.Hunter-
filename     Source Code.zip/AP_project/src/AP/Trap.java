package AP;

import java.io.Serializable;

public class Trap implements Serializable {
	int x, y;

	public Trap(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
}