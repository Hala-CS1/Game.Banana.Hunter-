package AP;

import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.control.Alert.AlertType;
import javafx.geometry.Insets;

public class GameTest extends Application {

    private Timeline timeline;
    private Scene gameScene;
    private BorderPane gameRoot;

    private Label coinsLabel;
    private Label levelLabel;
    private Label timeLabel;

    private Label resultLabel;

    private Scene endScene;
    private VBox endRoot;

    @Override
    public void start(Stage stage) {

        // LABELS
        coinsLabel = new Label("Coins: 0");
        levelLabel = new Label("Level: 1");
        timeLabel = new Label("Time: 30");

        coinsLabel.setFont(Font.font(18));
        levelLabel.setFont(Font.font(18));
        timeLabel.setFont(Font.font(18));

        HBox top = new HBox(30, coinsLabel, levelLabel, timeLabel);
        top.setAlignment(Pos.CENTER);

        resultLabel = new Label("");
        resultLabel.setFont(Font.font(40));

        gameRoot = new BorderPane();
        gameRoot.setTop(top);

        gameScene = new Scene(gameRoot, 800, 600);

        // END SCREEN
        endRoot = new VBox(30);
        endRoot.setAlignment(Pos.CENTER);

        endScene = new Scene(endRoot, 800, 600);

        // START SCREEN
        Button startBtn = new Button("START");

        startBtn.setFont(Font.font(25));
        startBtn.setStyle("-fx-background-color: gold; -fx-text-fill: black;");

        VBox startRoot = new VBox(30, startBtn);

        startRoot.setAlignment(Pos.BOTTOM_CENTER);
        startRoot.setPadding(new Insets(0, 0, 120, 0));

        startRoot.setStyle(
                "-fx-background-image: url('file:/C:/Users/للاعمال/Downloads/bg2.jpg');" +
                "-fx-background-size: cover;" +
                "-fx-background-position: center;" +
                "-fx-border-color: gold;" +
                "-fx-border-width: 6;"
        );

        Scene startScene = new Scene(startRoot, 800, 600);

        // ACTION
        startBtn.setOnAction(e -> setupAndStartGame(stage));

        stage.setTitle("Banana Hunter");
        stage.setScene(startScene);
        stage.show();
    }

    private void setupAndStartGame(Stage stage) {

        Controller control = new Controller();
        Game view = new Game(control.player, control.coins, control.traps);

        StackPane centerPane = new StackPane();

        resultLabel.setText("");

        centerPane.getChildren().addAll(view, resultLabel);
        gameRoot.setCenter(centerPane);

        final int[] currentLevel = {1};

        // MOVEMENT
        gameScene.setOnKeyPressed(event -> {

            switch (event.getCode()) {
                case UP -> control.move(0, -10);
                case DOWN -> control.move(0, 10);
                case LEFT -> control.move(-10, 0);
                case RIGHT -> control.move(10, 0);
            }

            if (control.getLevel() != currentLevel[0]) {
                currentLevel[0] = control.getLevel();
                view.resetObjects(control.coins, control.traps);
            }

            view.updatePlayer(control.player);
            view.updateCoins(control.coins);
        });

        // GAME LOOP
        timeline = new Timeline(new KeyFrame(Duration.seconds(1), e -> {

            control.decrementTime();

            coinsLabel.setText("Coins: " + control.getScore());
            levelLabel.setText("Level: " + control.getLevel());
            timeLabel.setText("Time: " + control.getTime());

            view.updatePlayer(control.player);
            view.updateCoins(control.coins);
            view.updateLight(control.player, control.getLevel());

            // GAME OVER
            if (control.gameOver) {

                timeline.stop();

                boolean win =
                        control.getLevel() == 2 &&
                        control.coins.stream().allMatch(c -> c.collected);

                String imgPath = win
                        ? "file:/C:/Users/للاعمال/Downloads/win.jpg"
                        : "file:/C:/Users/للاعمال/Downloads/lose.jpg";

                Label finalInfo = new Label(
                        "Score: " + control.getScore() +
                        "   Level: " + control.getLevel()
                );

                finalInfo.setFont(Font.font(30));
                finalInfo.setTextFill(Color.WHITE);

                Button yes = new Button("Play Again");
                Button no = new Button("Exit");

                yes.setFont(Font.font(25));
                no.setFont(Font.font(25));

                yes.setStyle("-fx-background-color: gold; -fx-text-fill: black;");
                no.setStyle("-fx-background-color: gold; -fx-text-fill: black;");

                yes.setOnAction(ev -> setupAndStartGame(stage));

                no.setOnAction(ev -> {

                    Alert bye = new Alert(AlertType.INFORMATION);
                    bye.setTitle("Thanks for playing!");
                    bye.setHeaderText(null);
                    bye.setContentText("Bye!");
                    bye.showAndWait();

                    stage.close();
                });

                HBox choices = new HBox(20, yes, no);
                choices.setAlignment(Pos.CENTER);

                endRoot.getChildren().clear();
                endRoot.getChildren().addAll(finalInfo, choices);

                endRoot.setStyle(
                        "-fx-background-image: url('" + imgPath + "');" +
                        "-fx-background-size: cover;" +
                        "-fx-background-position: center;" +
                        "-fx-border-color: gold;" +
                        "-fx-border-width: 6;"
                );

                stage.setScene(endScene);
            }
        }));

        timeline.setCycleCount(Timeline.INDEFINITE);

        stage.setScene(gameScene);
        timeline.play();
    }

    public static void main(String[] args) {
        launch(args);
    }
}